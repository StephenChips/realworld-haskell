#! runhaskell
import Distribution.Simple
main = defaultMain